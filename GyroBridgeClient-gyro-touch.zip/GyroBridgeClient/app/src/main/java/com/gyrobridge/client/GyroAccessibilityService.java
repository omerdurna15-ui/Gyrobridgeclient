package com.gyrobridge.client;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;

/**
 * Converts phone gyro movement into short touchscreen swipes while the
 * target Minecraft package is in the foreground.
 *
 * This uses Android's accessibility gesture API; it does not modify Minecraft.
 */
public class GyroAccessibilityService extends AccessibilityService implements SensorEventListener {
    public static volatile GyroAccessibilityService INSTANCE;

    private static final String TARGET_PACKAGE = "com.mojang.minecraftpe";
    private static final long MIN_GESTURE_INTERVAL_MS = 28L;
    private static final float PIXELS_PER_RAD = 95.0f;
    private static final float DEADZONE = 0.015f;

    private SensorManager sensorManager;
    private Sensor gyro;
    private boolean enabled = false;
    private boolean targetForeground = false;
    private long lastGesture = 0L;
    private float sx = 0f;
    private float sy = 0f;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyro = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) : null;
    }

    public void setEnabled(boolean value) {
        enabled = value;
        if (!enabled && sensorManager != null) sensorManager.unregisterListener(this);
        if (enabled && gyro != null && sensorManager != null) {
            sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    public boolean isEnabledByUser() {
        return enabled;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkg = event.getPackageName();
        targetForeground = pkg != null && TARGET_PACKAGE.contentEquals(pkg);
    }

    @Override
    public void onInterrupt() {
        // No-op.
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!enabled || !targetForeground || event.sensor.getType() != Sensor.TYPE_GYROSCOPE) return;

        long now = SystemClock.uptimeMillis();
        if (now - lastGesture < MIN_GESTURE_INTERVAL_MS) return;
        lastGesture = now;

        float rawYaw = event.values[1];
        float rawPitch = event.values[0];
        if (Math.abs(rawYaw) < DEADZONE) rawYaw = 0f;
        if (Math.abs(rawPitch) < DEADZONE) rawPitch = 0f;

        sx += (rawYaw - sx) * 0.24f;
        sy += (rawPitch - sy) * 0.24f;

        float dx = clamp(-sx * PIXELS_PER_RAD, -42f, 42f);
        float dy = clamp(sy * PIXELS_PER_RAD, -32f, 32f);
        if (Math.abs(dx) < 1f && Math.abs(dy) < 1f) return;

        dispatchCameraSwipe(dx, dy);
    }

    private void dispatchCameraSwipe(float dx, float dy) {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * 0.78f;
        float y = dm.heightPixels * 0.52f;
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x + dx, y + dy);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 22))
                .build();
        dispatchGesture(gesture, null, null);
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    public void onDestroy() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }
}
