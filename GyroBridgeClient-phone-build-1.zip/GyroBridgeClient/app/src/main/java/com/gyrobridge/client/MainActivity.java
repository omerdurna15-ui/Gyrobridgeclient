package com.gyrobridge.client;

import android.app.Activity;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Standalone Android gyro bridge.
 *
 * Reads TYPE_GYROSCOPE (rad/s) and publishes a small UDP packet to localhost.
 * A Minecraft native module can listen on UDP port 27440 and map the axes to
 * camera yaw/pitch. The bridge intentionally sends angular velocity + dt rather
 * than pretending gyro values are absolute angles.
 */
public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor gyro;
    private TextView status, values, packets, sensitivityText;
    private boolean running = false;
    private DatagramSocket socket;
    private Thread senderThread;
    private volatile String latestPacket;
    private long lastTimestampNs = 0L;
    private float sx = 0f, sy = 0f, sz = 0f;
    private float smooth = 0.18f;
    private float sensitivity = 1.0f;
    private long packetCount = 0;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyro = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) : null;
        buildUi();
    }

    private TextView tv(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setPadding(0, 8, 0, 8); return t;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.rgb(16,19,24));

        TextView title = tv("GyroBridge Client", 28);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        status = tv(gyro == null ? "Jiroskop bulunamadı" : "Hazır — jiroskop bulundu", 16);
        status.setTextColor(Color.rgb(170,180,192));
        root.addView(status);

        values = tv("X: 0.000\nY: 0.000\nZ: 0.000\ndt: 0 ms", 18);
        root.addView(values);

        TextView info = tv("UDP hedefi: 127.0.0.1:27440", 15);
        info.setTextColor(Color.rgb(170,180,192));
        root.addView(info);

        sensitivityText = tv("Hassasiyet: 1.00x", 15);
        sensitivityText.setTextColor(Color.rgb(170,180,192));
        root.addView(sensitivityText);

        SeekBar sens = new SeekBar(this);
        sens.setMax(200);
        sens.setProgress(100);
        sens.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                sensitivity = Math.max(0.05f, p / 100f);
                sensitivityText.setText(String.format(Locale.US, "Hassasiyet: %.2fx", sensitivity));
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        root.addView(sens);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        Button start = new Button(this); start.setText("BAŞLAT");
        Button stop = new Button(this); stop.setText("DURDUR");
        row.addView(start, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(stop, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        packets = tv("Gönderilen paket: 0", 15);
        packets.setTextColor(Color.rgb(170,180,192));
        root.addView(packets);

        TextView note = tv("Not: Bu sürüm Android jiroskopunu okuyup yerel UDP köprüsü sağlar. Minecraft kamera kontrolü için buna bağlanan native modül gerekir.", 14);
        note.setTextColor(Color.rgb(170,180,192));
        root.addView(note);

        start.setOnClickListener(v -> startBridge());
        stop.setOnClickListener(v -> stopBridge());
        setContentView(root);
    }

    private void startBridge() {
        if (gyro == null) { status.setText("Bu cihazda jiroskop yok."); return; }
        if (running) return;
        running = true; packetCount = 0; lastTimestampNs = 0L;
        sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
        status.setText("Çalışıyor — jiroskop verisi okunuyor");
        senderThread = new Thread(() -> {
            try {
                socket = new DatagramSocket();
                while (running) {
                    String packet = latestPacket;
                    if (packet != null) sendUdp(packet);
                    SystemClock.sleep(8);
                }
            } catch (Exception ignored) {
                runOnUiThread(() -> status.setText("UDP gönderimi başlatılamadı"));
            }
        }, "gyro-udp");
        senderThread.start();
    }

    private void stopBridge() {
        running = false;
        if (sensorManager != null) sensorManager.unregisterListener(this);
        if (socket != null) { socket.close(); socket = null; }
        status.setText("Durduruldu");
    }

    private void sendUdp(String text) {
        try {
            byte[] data = text.getBytes(StandardCharsets.UTF_8);
            DatagramPacket packet = new DatagramPacket(data, data.length,
                    InetAddress.getByName("127.0.0.1"), 27440);
            socket.send(packet);
            packetCount++;
            runOnUiThread(() -> packets.setText("Gönderilen paket: " + packetCount));
        } catch (Exception ignored) {}
    }

    @Override public void onSensorChanged(SensorEvent e) {
        if (!running || e.sensor.getType() != Sensor.TYPE_GYROSCOPE) return;
        long now = e.timestamp;
        float dt = lastTimestampNs == 0L ? 0f : (now - lastTimestampNs) / 1_000_000_000f;
        lastTimestampNs = now;
        if (dt <= 0f || dt > 0.2f) dt = 0.016f;

        // Exponential smoothing. Raw gyro values remain angular velocity in rad/s.
        float targetX = e.values[0] * sensitivity;
        float targetY = e.values[1] * sensitivity;
        float targetZ = e.values[2] * sensitivity;
        sx += (targetX - sx) * smooth;
        sy += (targetY - sy) * smooth;
        sz += (targetZ - sz) * smooth;

        latestPacket = String.format(Locale.US, "GYRO 1 %.6f %.6f %.6f %.6f\\n", sx, sy, sz, dt);
        String ui = String.format(Locale.US, "X: %.3f rad/s\\nY: %.3f rad/s\\nZ: %.3f rad/s\\ndt: %.1f ms", sx, sy, sz, dt * 1000f);
        runOnUiThread(() -> values.setText(ui));
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    @Override protected void onPause() { super.onPause(); if (running) stopBridge(); }
    @Override protected void onDestroy() { stopBridge(); super.onDestroy(); }
}
