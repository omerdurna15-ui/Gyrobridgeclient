# Accessibility freeze fix

The previous build created a full-screen touchable overlay inside `onServiceConnected()`, so enabling the accessibility service immediately intercepted the whole screen.

This build keeps only the small GYRO toggle window while OFF. The full-screen touch-capture window is created only after the user turns GYRO ON.

This removes the immediate screen-lock behavior when accessibility permission is enabled.
