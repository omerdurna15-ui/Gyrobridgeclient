# Joystick limitation

This version improves gyro response by integrating the sensor values over time and accumulating fractional screen movement before sending gestures.

The separate joystick issue cannot be fully solved with Android AccessibilityService's `dispatchGesture()` path: Android cancels any gestures currently in progress when a new accessibility gesture is dispatched. That means a live joystick touch can be interrupted when a gyro gesture is injected.

Solving true simultaneous joystick + gyro input requires a lower-level input injection path or a native integration inside the game/client, rather than accessibility gesture injection.
