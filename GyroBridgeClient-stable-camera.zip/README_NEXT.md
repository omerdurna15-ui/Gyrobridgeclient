# GyroBridgeClient - stable camera build

This build intentionally keeps the proven gesture timing from the working landscape version:
- gesture duration is shorter than the minimum interval, avoiding overlapping accessibility gestures
- stronger gyro response
- lower deadzone and lighter smoothing
- landscape axis mapping preserved

Important: Android AccessibilityService `dispatchGesture()` can interfere with ongoing user touches. This build prioritizes restoring reliable camera movement; it does not promise simultaneous joystick use.
