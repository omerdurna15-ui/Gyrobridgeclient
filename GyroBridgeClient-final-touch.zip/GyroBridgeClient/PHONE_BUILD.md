# Telefonda APK alma

Bu proje GitHub Actions ile bilgisayar olmadan derlenebilir.

1. GitHub'da yeni, boş bir repository oluştur.
2. Bu klasördeki dosyaları repository'ye yükle. `.github/workflows/build-apk.yml` dosyasının da yüklendiğinden emin ol.
3. GitHub repository içinde **Actions** sekmesini aç.
4. `Build Android APK` iş akışını seç ve **Run workflow** ile çalıştır. Push yaptığında da otomatik çalışır.
5. İşlem tamamlanınca ilgili workflow çalışmasının altında **Artifacts** bölümünden `GyroBridgeClient-debug-apk` dosyasını indir.
6. ZIP'i çıkarıp `app-debug.apk` dosyasını Android'e kurabilirsin.

Bu APK yalnızca jiroskop köprüsüdür. Minecraft kamera entegrasyonu içermez.
