# Minecraft native modül entegrasyon notu

Native tarafta UDP 127.0.0.1:27440 dinlenir. Her paketten x/y/z ve dt okunur.

Örnek mantık:

    yaw   += mapY * dt * sensitivity;
    pitch += mapX * dt * sensitivity;

Ardından pitch'i Minecraft'ın kabul ettiği aralıkta clamp etmek ve eksen işaretlerini cihaz üzerinde kalibre etmek gerekir.

Bu dosyada gerçek Bedrock internal sembol/offset bilgisi verilmemiştir; bunlar Minecraft sürümüne göre değişir ve ayrıca sürüm-spesifik native entegrasyon gerektirir.
