# Gyro touch fixed

This revision fixes a common failure mode in the first gyro-touch build: the service required the foreground app package to be exactly `com.mojang.minecraftpe`. Some Android Minecraft builds use a different package ID, so the camera button could appear to do nothing.

The accessibility service now activates whenever an app other than GyroBridge itself is in the foreground. It also spaces camera swipes farther apart and increases their range so the effect is easier to notice.

After installing:
1. Enable the GyroBridge accessibility service.
2. Open GyroBridge and tap `KAMERA MODUNU BAŞLAT / DURDUR`.
3. Open Minecraft and use the right-side camera area while moving the phone.
4. If the status says the service is not connected, turn the accessibility service off and on again in Android settings.
