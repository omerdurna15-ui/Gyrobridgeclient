package com.gyrobridge.client;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;

/**
 * Converts phone gyro movement into short touchscreen swipes while a non-GyroBridge
 * app is in the foreground. This does not modify or patch Minecraft.
 */
public class GyroAccessibilityService extends AccessibilityService implements SensorEventListener {
    public static volatile GyroAccessibilityService INSTANCE;

    private static final long MIN_GESTURE_INTERVAL_MS = 55L;
    private static final long GESTURE_DURATION_MS = 45L;
    private static final float PIXELS_PER_RAD = 230.0f;
    private static final float DEADZONE = 0.020f;
    private static final float SMOOTHING = 0.32f;
    private static final float MAX_DX = 115f;
    private static final float MAX_DY = 90f;

    private SensorManager sensorManager;
    private Sensor gyro;
    private boolean enabled = false;
    private boolean targetForeground = false;
    private String foregroundPackage = "";
    private long lastGesture = 0L;
    private float filteredX = 0f;
    private float filteredY = 0f;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyro = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) : null;
    }

    public void setEnabled(boolean value) {
        enabled = value;
        if (sensorManager == null || gyro == null) return;
        sensorManager.unregisterListener(this);
        if (enabled) {
            sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    public boolean isEnabledByUser() {
        return enabled;
    }

    /** Sends one small, visible swipe so the user can verify accessibility gestures work. */
    public void sendTestSwipe() {
        if (!targetForeground) return;
        dispatchCameraSwipe(80f, 0f);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkg = event.getPackageName();
        foregroundPackage = pkg == null ? "" : pkg.toString();
        targetForeground = !foregroundPackage.equals(getPackageName()) && !foregroundPackage.isEmpty();
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!enabled || !targetForeground || event.sensor.getType() != Sensor.TYPE_GYROSCOPE) return;

        long now = SystemClock.uptimeMillis();
        if (now - lastGesture < MIN_GESTURE_INTERVAL_MS) return;

        float horizontal = event.values[1];  // phone yaw-like rotation
        float vertical = event.values[0];    // phone pitch-like rotation

        if (Math.abs(horizontal) < DEADZONE) horizontal = 0f;
        if (Math.abs(vertical) < DEADZONE) vertical = 0f;

        filteredX += (horizontal - filteredX) * SMOOTHING;
        filteredY += (vertical - filteredY) * SMOOTHING;

        float dx = clamp(-filteredX * PIXELS_PER_RAD, -MAX_DX, MAX_DX);
        float dy = clamp(-filteredY * PIXELS_PER_RAD, -MAX_DY, MAX_DY);
        if (Math.abs(dx) < 2f && Math.abs(dy) < 2f) return;

        if (dispatchCameraSwipe(dx, dy)) {
            lastGesture = now;
        }
    }

    private boolean dispatchCameraSwipe(float dx, float dy) {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        // Keep the gesture away from the extreme edges, where Android navigation
        // gestures or Minecraft UI elements are more likely to interfere.
        float x = dm.widthPixels * 0.72f;
        float y = dm.heightPixels * 0.52f;

        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x + dx, y + dy);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, GESTURE_DURATION_MS))
                .build();

        return dispatchGesture(gesture, null, null);
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    public void onDestroy() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }
}
