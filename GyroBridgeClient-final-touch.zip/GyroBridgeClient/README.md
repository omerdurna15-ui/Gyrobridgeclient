# GyroBridge Client

Android prototipi: telefonun `TYPE_GYROSCOPE` sensörünü okur, veriyi hafifçe yumuşatır ve `127.0.0.1:27440` UDP portuna yollar.

## Paket biçimi

```text
GYRO 1 <x_rad_s> <y_rad_s> <z_rad_s> <dt_seconds>\n
```

`x/y/z` Android'in lokal eksenlerindeki açısal hızdır. Bir Minecraft native modülü bu veriyi kamera eksenlerine eşleyip `dt` ile entegre ederek yaw/pitch değişimine çevirebilir.

## Bilgisayarsız derleme

`.github/workflows/build-apk.yml` GitHub Actions ile debug APK üretir. Telefonda repository'yi açıp **Actions → Build Android APK → Run workflow** ile çalıştırabilirsin. Sonuç `GyroBridgeClient-debug-apk` artifact'i olarak yüklenir.

## Sınır

Bu proje Minecraft APK'sı veya değiştirilmiş Minecraft binary'si içermez. Minecraft kamera kontrolü için ayrıca sürüme özgü native entegrasyon gerekir.
