# Final Touch Mode

This build uses Android AccessibilityService gesture dispatch to emulate camera swipes from gyro movement.

1. Install the APK.
2. Enable `GyroBridge Client` in Accessibility settings.
3. Return to the app and enable `KAMERA MODUNU BAŞLAT / DURDUR`.
4. Bring Minecraft to the foreground.
5. Use `DOKUNMA TESTİ (SAĞA KAYDIR)` once to verify that accessibility gestures are being sent.
6. Move the phone to steer the camera.

This does not patch or modify the Minecraft APK. Because touch injection is done through Android AccessibilityService, behavior can vary by Android version and by the game's input handling.
