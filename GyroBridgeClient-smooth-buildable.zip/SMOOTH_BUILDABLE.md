# Smooth buildable gyro version

Built from the previously working landscape/overlay version.
Only the smoothing/timing logic was changed to keep the Android build simple and compatible.
