# Overlay camera toggle

The camera control is now OFF by default. After enabling the accessibility service and the "draw over other apps" permission, a small `GYRO OFF` button stays above other apps. Tap it to switch the gyro camera to ON; tap again to turn it OFF. The button can be dragged.
