## Next build: Virtual Multi-Touch

The key change is in `GyroAccessibilityService.java`: real user touches and the synthetic gyro camera finger are emitted in the same `GestureDescription`, using `continueStroke()` between segments.

This means the app no longer injects a separate gesture that fights the joystick gesture.
