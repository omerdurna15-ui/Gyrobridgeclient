# Smooth gyro v2

- 16 ms continuous stroke segments
- dt-based integration
- light adaptive smoothing
- low deadzone
- subpixel state preserved in float coordinates
- existing GYRO ON/OFF overlay and multitouch bridge retained
