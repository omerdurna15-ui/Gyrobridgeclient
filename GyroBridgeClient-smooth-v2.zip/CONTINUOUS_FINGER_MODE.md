# Continuous Finger Mode

This build uses Android Accessibility `GestureDescription.StrokeDescription.continueStroke()` to keep a synthetic pointer down while the virtual finger is moved by gyroscope input.

The gesture is released only when Gyro is turned off or the target app changes.
