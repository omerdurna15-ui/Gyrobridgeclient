# Virtual Multi-Touch Gyro Mode

This build uses one accessibility gesture stream for both the synthetic camera pointer and captured user touches.

When GYRO is ON, the overlay captures screen touches, replays them to the foreground app as additional pointers, and keeps a separate camera pointer continuously held down and moved by the gyroscope.

This is designed to avoid the older failure mode where a separate gyro gesture canceled the joystick/button touch.

The first test should verify: joystick, jump/attack buttons, and gyro camera can be used together.
