# Overlay toggle

The GYRO ON/OFF control appears after the Android "Display over other apps" permission is granted.
The overlay is intentionally a small button-only window; it does NOT cover the Minecraft screen.

Steps:
1. Enable the accessibility service.
2. Enable "Display over other apps" for GyroBridge.
3. Return to GyroBridge; the floating GYRO OFF button appears.
4. Tap it to switch to GYRO ON/OFF.
