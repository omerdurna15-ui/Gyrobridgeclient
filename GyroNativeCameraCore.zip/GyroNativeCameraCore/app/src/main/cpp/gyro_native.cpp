#include <jni.h>
#include <android/log.h>
#include <cmath>
#include <algorithm>
#include <mutex>

#define LOG_TAG "GyroNative"
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
std::mutex g_mutex;
bool g_running = false;
long long g_lastNs = 0;
float g_sensitivity = 1.0f;
float g_smoothing = 0.12f;
float g_deadzone = 0.015f;
float g_fYaw = 0.0f;
float g_fPitch = 0.0f;
float g_accYaw = 0.0f;
float g_accPitch = 0.0f;

float expAlpha(float smoothing, float dt) {
    // smoothing is interpreted as the nominal per-60Hz smoothing amount.
    const float base = std::clamp(1.0f - smoothing, 0.001f, 1.0f);
    const float frames = std::clamp(dt * 60.0f, 0.05f, 4.0f);
    return 1.0f - std::pow(base, frames);
}

void resetState() {
    g_lastNs = 0;
    g_fYaw = g_fPitch = 0.0f;
    g_accYaw = g_accPitch = 0.0f;
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_gyro_nativecamera_GyroNative_nativeStart(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_running = true;
    resetState();
}

extern "C" JNIEXPORT void JNICALL
Java_com_gyro_nativecamera_GyroNative_nativeStop(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_running = false;
    resetState();
}

extern "C" JNIEXPORT void JNICALL
Java_com_gyro_nativecamera_GyroNative_nativeConfigure(JNIEnv*, jclass,
                                                       jfloat sensitivity,
                                                       jfloat smoothing,
                                                       jfloat deadzone) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_sensitivity = sensitivity;
    g_smoothing = smoothing;
    g_deadzone = deadzone;
}

extern "C" JNIEXPORT void JNICALL
Java_com_gyro_nativecamera_GyroNative_nativeSensor(JNIEnv*, jclass,
                                                   jlong timestampNs,
                                                   jfloat x,
                                                   jfloat y,
                                                   jfloat z) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_running) return;

    if (g_lastNs == 0) {
        g_lastNs = timestampNs;
        return;
    }

    const long long dNs = timestampNs - g_lastNs;
    g_lastNs = timestampNs;
    if (dNs <= 0) return;

    float dt = static_cast<float>(dNs) * 1e-9f;
    dt = std::clamp(dt, 0.001f, 0.05f);

    // Landscape mapping for a typical portrait sensor frame.
    // Tune signs at the host layer if the device orientation differs.
    const float rawYawRate = -y;
    const float rawPitchRate = -x;

    auto applyDeadzone = [](float v, float dz) -> float {
        if (std::fabs(v) <= dz) return 0.0f;
        const float sign = v < 0.0f ? -1.0f : 1.0f;
        return sign * (std::fabs(v) - dz);
    };

    const float yawRate = applyDeadzone(rawYawRate, g_deadzone);
    const float pitchRate = applyDeadzone(rawPitchRate, g_deadzone);

    const float alpha = expAlpha(g_smoothing, dt);
    g_fYaw += (yawRate - g_fYaw) * alpha;
    g_fPitch += (pitchRate - g_fPitch) * alpha;

    // Sensitivity is expressed as screen-camera units per radian.
    g_accYaw += g_fYaw * dt * g_sensitivity;
    g_accPitch += g_fPitch * dt * g_sensitivity;
}

extern "C" JNIEXPORT void JNICALL
Java_com_gyro_nativecamera_GyroNative_nativeConsumeDelta(JNIEnv* env, jclass, jfloatArray out) {
    if (env == nullptr || out == nullptr || env->GetArrayLength(out) < 2) return;
    std::lock_guard<std::mutex> lock(g_mutex);
    const jfloat values[2] = {g_accYaw, g_accPitch};
    env->SetFloatArrayRegion(out, 0, 2, values);
    g_accYaw = 0.0f;
    g_accPitch = 0.0f;
}
