package com.gyro.nativecamera;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;

/**
 * Java-side sensor owner. The actual filtering/integration is native.
 */
public final class GyroNative implements SensorEventListener, AutoCloseable {
    static {
        System.loadLibrary("gyronative");
    }

    private final SensorManager sensorManager;
    private final Sensor gyroscope;
    private boolean running;

    public GyroNative(Context context) {
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null) {
            throw new IllegalStateException("SensorManager unavailable");
        }
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if (gyroscope == null) {
            throw new IllegalStateException("Gyroscope unavailable on this device");
        }
    }

    public synchronized void start() {
        if (running) return;
        if (!sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_GAME)) {
            throw new IllegalStateException("Could not register gyroscope");
        }
        running = true;
        nativeStart();
    }

    public synchronized void stop() {
        if (!running) return;
        sensorManager.unregisterListener(this);
        running = false;
        nativeStop();
    }

    public void configure(float sensitivity, float smoothing, float deadzone) {
        if (!Float.isFinite(sensitivity) || sensitivity <= 0f) {
            throw new IllegalArgumentException("sensitivity must be > 0");
        }
        if (!Float.isFinite(smoothing) || smoothing < 0f || smoothing >= 1f) {
            throw new IllegalArgumentException("smoothing must be in [0,1)");
        }
        if (!Float.isFinite(deadzone) || deadzone < 0f) {
            throw new IllegalArgumentException("deadzone must be >= 0");
        }
        nativeConfigure(sensitivity, smoothing, deadzone);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_GYROSCOPE || event.values.length < 3) return;
        // Android SensorEvent timestamps are nanoseconds based on the same clock source.
        nativeSensor(event.timestamp, event.values[0], event.values[1], event.values[2]);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // No-op. Gyro integration does not need an accuracy callback.
    }

    @Override
    public synchronized void close() {
        stop();
    }

    /** Retrieve and clear the integrated camera delta. Returns {yaw, pitch}. */
    public float[] consumeDelta() {
        float[] out = new float[2];
        nativeConsumeDelta(out);
        return out;
    }

    private static native void nativeStart();
    private static native void nativeStop();
    private static native void nativeConfigure(float sensitivity, float smoothing, float deadzone);
    private static native void nativeSensor(long timestampNs, float x, float y, float z);
    private static native void nativeConsumeDelta(float[] outYawPitch);
}
