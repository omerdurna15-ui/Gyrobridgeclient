# Native hook plan

The supplied Minecraft APK exposes the following GameActivity symbols in `lib/arm64-v8a/libminecraftpe.so`:

- `GameActivityMotionEvent_fromJava`
- `GameActivityMotionEvent_getHistoricalAxisValue`
- `GameActivityPointerAxes_getAxisValue`
- `android_app_swap_input_buffers`
- `android_app_set_motion_event_filter`
- `GameActivity_onCreate`

Google's GameActivity API documents that touch input is represented as `GameActivityMotionEvent` and delivered to native code through the input buffer / `onTouchEvent` path. This means a native integration should avoid AccessibilityService entirely.

The remaining host-specific task is to connect `GyroNative.consumeDelta()` to Bedrock's camera update path (or, preferably, to the game's own native camera-input accumulator). The APK's internal Bedrock camera symbols are not public/exported, so a hard-coded address would be unsafe and version-specific.

Do not distribute or embed the supplied Minecraft APK in this source package.
