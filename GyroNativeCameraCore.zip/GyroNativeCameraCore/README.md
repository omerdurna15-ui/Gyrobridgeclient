# GyroNativeCameraCore

Native gyro core for an Android GameActivity host.

The goal is:

Gyroscope -> timestamped angular velocity -> filtered yaw/pitch deltas -> native game camera callback.

This package intentionally does **not** contain or redistribute Minecraft binaries. It also does not use AccessibilityService or overlay touch injection.

## What is implemented

- Android `Sensor.TYPE_GYROSCOPE`
- timestamp-based integration (`dt`)
- adaptive smoothing
- deadzone
- sub-pixel accumulation
- configurable sensitivity
- thread-safe native delta retrieval
- Java/JNI bridge suitable for a GameActivity-based host

## What remains host-specific

The final `applyCameraDelta(yaw,pitch)` call must be connected to the host game's camera/input callback. The supplied Minecraft APK exposes GameActivity input symbols, but the internal Bedrock camera function is not an exported/public API. This project therefore avoids guessing a hard-coded address.
