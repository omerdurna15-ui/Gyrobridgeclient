package com.gyrobridge.client;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.accessibility.AccessibilityEvent;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

/**
 * Gyro + touch bridge.
 *
 * Design:
 * - When GYRO is OFF, there is no full-screen touch window.
 * - When GYRO is ON, a transparent full-screen overlay captures the user's
 *   touches and forwards them to the foreground app through the accessibility
 *   gesture API while also keeping one continuous synthetic "finger" for gyro.
 * - Pointer continuity is preserved with StrokeDescription.continueStroke().
 * - Frames are serialized: the next gesture is dispatched only after the
 *   previous one completes/cancels, which avoids overlapping dispatchGesture calls.
 */
public class GyroAccessibilityService extends AccessibilityService implements SensorEventListener {
    public static volatile GyroAccessibilityService INSTANCE;

    private static final long FRAME_DURATION_MS = 20L;
    private static final float PIXELS_PER_RAD = 900f;
    private static final float DEFAULT_SENSITIVITY = 1.0f;
    private static final float MIN_SENSITIVITY = 0.25f;
    private static final float MAX_SENSITIVITY = 3.0f;
    private static final float DEADZONE_RAD_S = 0.008f;
    private static final float MAX_MOVE_PER_FRAME = 28f;
    private static final float GYRO_CENTER_X_RATIO = 0.76f;
    private static final float GYRO_CENTER_Y_RATIO = 0.52f;
    private static final int MAX_FORWARDED_POINTERS = 4; // +1 gyro stroke; stays within GestureDescription stroke limit

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Map<Integer, TouchState> touches = new HashMap<>();

    private SensorManager sensorManager;
    private Sensor gyro;
    private WindowManager windowManager;

    private TextView overlayButton;
    private WindowManager.LayoutParams overlayParams;
    private boolean overlayShown;

    private FrameLayout touchRoot;
    private WindowManager.LayoutParams touchParams;
    private boolean touchOverlayShown;

    private boolean enabled;
    private boolean targetForeground;
    private String foregroundPackage = "";

    private boolean dispatchInFlight;
    private boolean retryPending;
    private int cancelCount;

    private long lastGyroTimestampNs;
    private float filteredGX;
    private float filteredGY;
    private float gyroTargetX;
    private float gyroTargetY;
    private StrokeState gyroStroke = new StrokeState();

    private float sensitivity = DEFAULT_SENSITIVITY;

    private float overlayDownX, overlayDownY;
    private int overlayStartX, overlayStartY;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyro = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) : null;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mainHandler.post(this::ensureOverlay);
    }

    public void ensureOverlay() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post(this::ensureOverlay);
            return;
        }
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (!Settings.canDrawOverlays(this)) return;
        if (overlayShown && overlayButton != null) return;

        overlayButton = new TextView(this);
        overlayButton.setText("GYRO\nOFF");
        overlayButton.setTextColor(Color.WHITE);
        overlayButton.setTextSize(12f);
        overlayButton.setGravity(Gravity.CENTER);
        overlayButton.setPadding(10, 6, 10, 6);
        overlayButton.setBackground(makeBackground(false));
        overlayButton.setElevation(20f);

        overlayButton.setOnClickListener(v -> setEnabled(!enabled));
        overlayButton.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    overlayDownX = event.getRawX();
                    overlayDownY = event.getRawY();
                    overlayStartX = overlayParams.x;
                    overlayStartY = overlayParams.y;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    int nx = overlayStartX + (int) (event.getRawX() - overlayDownX);
                    int ny = overlayStartY + (int) (event.getRawY() - overlayDownY);
                    overlayParams.x = nx;
                    overlayParams.y = ny;
                    try {
                        windowManager.updateViewLayout(overlayButton, overlayParams);
                    } catch (Exception ignored) { }
                    return true;
                default:
                    return false;
            }
        });

        int type;
        if (Build.VERSION.SDK_INT >= 26) {
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
        } else {
            type = WindowManager.LayoutParams.TYPE_PHONE;
        }
        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.END;
        overlayParams.x = 18;
        overlayParams.y = 110;

        try {
            windowManager.addView(overlayButton, overlayParams);
            overlayShown = true;
            updateOverlayText();
        } catch (Exception e) {
            Toast.makeText(this, "Kamera tuşu gösterilemedi: Üstte gösterme iznini kontrol et.", Toast.LENGTH_SHORT).show();
        }
    }

    private GradientDrawable makeBackground(boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(on ? Color.rgb(18, 165, 90) : Color.rgb(70, 75, 82));
        bg.setCornerRadius(28f);
        bg.setStroke(2, Color.WHITE);
        return bg;
    }

    public void setEnabled(boolean value) {
        mainHandler.post(() -> setEnabledOnMain(value));
    }

    private void setEnabledOnMain(boolean value) {
        if (enabled == value) return;
        enabled = value;
        resetTracking();

        if (sensorManager != null && gyro != null) {
            sensorManager.unregisterListener(this);
            if (enabled) {
                sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_FASTEST, mainHandler);
            }
        }

        if (enabled) {
            if (!Settings.canDrawOverlays(this)) {
                enabled = false;
                Toast.makeText(this, "Önce 'Üstte gösterme' iznini aç.", Toast.LENGTH_SHORT).show();
            } else {
                showTouchOverlay();
                mainHandler.post(this::requestNextFrame);
            }
        } else {
            hideTouchOverlay();
        }

        updateOverlayText();
    }

    public boolean isEnabledByUser() { return enabled; }

    private void updateOverlayText() {
        if (overlayButton == null) return;
        overlayButton.setText(enabled ? "GYRO\nON" : "GYRO\nOFF");
        overlayButton.setBackground(makeBackground(enabled));
    }

    public void setSensitivity(float value) {
        sensitivity = clamp(value, MIN_SENSITIVITY, MAX_SENSITIVITY);
    }

    public float getSensitivity() { return sensitivity; }

    public void sendTestSwipe() {
        mainHandler.post(() -> {
            if (!targetForeground) {
                Toast.makeText(this, "Önce test yapılacak uygulamaya geç.", Toast.LENGTH_SHORT).show();
                return;
            }
            // Reuse the same serialized dispatcher.
            gyroTargetX += 120f;
            requestNextFrame();
        });
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkg = event.getPackageName();
        foregroundPackage = pkg == null ? "" : pkg.toString();
        targetForeground = !foregroundPackage.equals(getPackageName()) && !foregroundPackage.isEmpty();
    }

    @Override public void onInterrupt() { }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!enabled || !targetForeground || event.sensor.getType() != Sensor.TYPE_GYROSCOPE) return;

        final long ts = event.timestamp;
        if (lastGyroTimestampNs == 0L) {
            lastGyroTimestampNs = ts;
            return;
        }

        float dt = (ts - lastGyroTimestampNs) / 1_000_000_000f;
        lastGyroTimestampNs = ts;
        if (dt <= 0f || dt > 0.08f) dt = 0.016f;

        float rawX = -event.values[0];
        float rawY = event.values[1];

        if (Math.abs(rawX) < DEADZONE_RAD_S) rawX = 0f;
        if (Math.abs(rawY) < DEADZONE_RAD_S) rawY = 0f;

        // Low-pass filter with a short time constant so small motion isn't erased.
        float alpha = 1f - (float) Math.exp(-2.0 * Math.PI * 12.0 * dt);
        filteredGX += (rawX - filteredGX) * alpha;
        filteredGY += (rawY - filteredGY) * alpha;

        float dx = clamp(filteredGX * dt * PIXELS_PER_RAD * sensitivity, -MAX_MOVE_PER_FRAME, MAX_MOVE_PER_FRAME);
        float dy = clamp(filteredGY * dt * PIXELS_PER_RAD * sensitivity, -MAX_MOVE_PER_FRAME, MAX_MOVE_PER_FRAME);

        gyroTargetX += dx;
        gyroTargetY += dy;

        // Keep the virtual finger inside the camera region.
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float centerX = dm.widthPixels * GYRO_CENTER_X_RATIO;
        float centerY = dm.heightPixels * GYRO_CENTER_Y_RATIO;
        gyroTargetX = clamp(gyroTargetX, 120f - centerX, dm.widthPixels - 120f - centerX);
        gyroTargetY = clamp(gyroTargetY, 90f - centerY, dm.heightPixels - 90f - centerY);

        mainHandler.post(this::requestNextFrame);
    }

    /**
     * Capture user touches only while gyro is enabled.  Each pointer is later
     * recreated as an accessibility stroke together with the gyro pointer.
     */
    private void handleTouchEvent(MotionEvent event) {
        if (!enabled) return;

        final int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            touches.clear();
            addPointer(event, event.getActionIndex());
        } else if (action == MotionEvent.ACTION_POINTER_DOWN) {
            if (touches.size() < MAX_FORWARDED_POINTERS) {
                addPointer(event, event.getActionIndex());
            }
        } else if (action == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < event.getPointerCount(); i++) {
                int id = event.getPointerId(i);
                TouchState s = touches.get(id);
                if (s != null) {
                    s.x = event.getX(i);
                    s.y = event.getY(i);
                }
            }
        } else if (action == MotionEvent.ACTION_POINTER_UP) {
            int index = event.getActionIndex();
            int id = event.getPointerId(index);
            TouchState s = touches.get(id);
            if (s != null) {
                s.x = event.getX(index);
                s.y = event.getY(index);
                s.ending = true;
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            int index = event.getActionIndex();
            if (index >= 0 && index < event.getPointerCount()) {
                int id = event.getPointerId(index);
                TouchState s = touches.get(id);
                if (s != null) {
                    s.x = event.getX(index);
                    s.y = event.getY(index);
                    s.ending = true;
                }
            }
            if (action == MotionEvent.ACTION_CANCEL) {
                for (TouchState s : touches.values()) s.ending = true;
            }
        }
        requestNextFrame();
    }

    private void addPointer(MotionEvent event, int index) {
        if (index < 0 || index >= event.getPointerCount()) return;
        int id = event.getPointerId(index);
        TouchState state = new TouchState(id, event.getX(index), event.getY(index));
        touches.put(id, state);
    }

    private void requestNextFrame() {
        if (!enabled || !targetForeground || dispatchInFlight) return;
        if (!touchOverlayShown) return;
        if (retryPending) return;
        retryPending = true;
        mainHandler.postDelayed(() -> {
            retryPending = false;
            dispatchFrame();
        }, 0L);
    }

    private void dispatchFrame() {
        if (!enabled || !targetForeground || dispatchInFlight) return;

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float cx = dm.widthPixels * GYRO_CENTER_X_RATIO;
        float cy = dm.heightPixels * GYRO_CENTER_Y_RATIO;
        float targetGX = cx + gyroTargetX;
        float targetGY = cy + gyroTargetY;

        GestureDescription.Builder builder = new GestureDescription.Builder();
        Map<Integer, StrokeState> strokeUpdates = new HashMap<>();

        // First: gyro finger.
        Path gyroPath = new Path();
        gyroPath.moveTo(gyroStroke.x, gyroStroke.y);
        gyroPath.lineTo(targetGX, targetGY);
        boolean gyroContinue = enabled;
        GestureDescription.StrokeDescription gyroDesc = makeStroke(gyroStroke, gyroPath, gyroContinue);
        builder.addStroke(gyroDesc);
        strokeUpdates.put(-1, new StrokeState(gyroDesc, targetGX, targetGY, true));

        // Then: up to MAX_FORWARDED_POINTERS real touch pointers.
        for (Iterator<Map.Entry<Integer, TouchState>> it = touches.entrySet().iterator(); it.hasNext();) {
            Map.Entry<Integer, TouchState> entry = it.next();
            TouchState s = entry.getValue();
            if (!s.dispatchedBefore && s.ending && !enabled) {
                it.remove();
                continue;
            }

            Path path = new Path();
            path.moveTo(s.strokeX, s.strokeY);
            path.lineTo(s.x, s.y);
            boolean willContinue = !s.ending;
            GestureDescription.StrokeDescription desc = makeStroke(s, path, willContinue);
            builder.addStroke(desc);
            strokeUpdates.put(s.id, new StrokeState(desc, s.x, s.y, willContinue));
        }

        GestureDescription gesture;
        try {
            // Android limits the number of strokes in a single gesture.
            // Keep one slot reserved for the virtual gyro finger.
            if (builder == null) return;
            gesture = builder.build();
        } catch (RuntimeException buildError) {
            dispatchInFlight = false;
            mainHandler.postDelayed(this::requestNextFrame, 8L);
            return;
        }
        dispatchInFlight = true;

        try {
            dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
                mainHandler.post(() -> finishFrame(true, strokeUpdates));
            }

            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
                mainHandler.post(() -> finishFrame(false, strokeUpdates));
            }
            }, mainHandler);
        } catch (RuntimeException dispatchError) {
            dispatchInFlight = false;
            gyroStroke = new StrokeState();
            for (TouchState s : touches.values()) {
                s.stroke = null;
                s.strokeX = s.x;
                s.strokeY = s.y;
            }
            mainHandler.postDelayed(this::requestNextFrame, 12L);
        }
    }

    private GestureDescription.StrokeDescription makeStroke(StrokeState state, Path path, boolean willContinue) {
        if (state.stroke != null && state.stroke.willContinue()) {
            return state.stroke.continueStroke(path, 0L, FRAME_DURATION_MS, willContinue);
        }
        return new GestureDescription.StrokeDescription(path, 0L, FRAME_DURATION_MS, willContinue);
    }

    private GestureDescription.StrokeDescription makeStroke(TouchState state, Path path, boolean willContinue) {
        if (state.stroke != null && state.stroke.willContinue()) {
            return state.stroke.continueStroke(path, 0L, FRAME_DURATION_MS, willContinue);
        }
        return new GestureDescription.StrokeDescription(path, 0L, FRAME_DURATION_MS, willContinue);
    }

    private void finishFrame(boolean completed, Map<Integer, StrokeState> updates) {
        dispatchInFlight = false;

        if (completed) {
            cancelCount = 0;
            StrokeState g = updates.get(-1);
            if (g != null) {
                gyroStroke = g;
            }

            for (Iterator<Map.Entry<Integer, TouchState>> it = touches.entrySet().iterator(); it.hasNext();) {
                Map.Entry<Integer, TouchState> entry = it.next();
                StrokeState u = updates.get(entry.getKey());
                TouchState s = entry.getValue();
                if (u != null) {
                    s.stroke = u.stroke;
                    s.strokeX = u.x;
                    s.strokeY = u.y;
                    s.dispatchedBefore = true;
                    if (s.ending) {
                        it.remove();
                    }
                }
            }
        } else {
            cancelCount++;
            // A cancelled gesture can't be continued safely; rebuild every stroke from current positions.
            gyroStroke = new StrokeState();
            for (TouchState s : touches.values()) {
                s.stroke = null;
                s.strokeX = s.x;
                s.strokeY = s.y;
            }
            if (cancelCount < 4 && enabled) {
                mainHandler.postDelayed(this::requestNextFrame, 2L);
            }
        }

        if (enabled) requestNextFrame();
    }

    private void showTouchOverlay() {
        if (touchOverlayShown) return;
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        touchRoot = new FrameLayout(this);
        touchRoot.setBackgroundColor(Color.TRANSPARENT);
        touchRoot.setOnTouchListener((v, event) -> {
            handleTouchEvent(event);
            return true;
        });

        int type;
        if (Build.VERSION.SDK_INT >= 26) {
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
        } else {
            type = WindowManager.LayoutParams.TYPE_PHONE;
        }
        touchParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        touchParams.gravity = Gravity.TOP | Gravity.START;
        touchParams.alpha = 0.01f;

        try {
            windowManager.addView(touchRoot, touchParams);
            touchOverlayShown = true;
        } catch (Exception e) {
            touchOverlayShown = false;
            Toast.makeText(this, "Dokunma köprüsü açılamadı. 'Üstte gösterme' iznini kontrol et.", Toast.LENGTH_SHORT).show();
        }
    }

    private void hideTouchOverlay() {
        touches.clear();
        dispatchInFlight = false;
        if (windowManager != null && touchRoot != null) {
            try { windowManager.removeViewImmediate(touchRoot); } catch (Exception ignored) { }
        }
        touchRoot = null;
        touchOverlayShown = false;
        resetTracking();
    }

    private void resetTracking() {
        touches.clear();
        dispatchInFlight = false;
        retryPending = false;
        lastGyroTimestampNs = 0L;
        filteredGX = filteredGY = 0f;
        gyroStroke = new StrokeState();
        gyroTargetX = 0f;
        gyroTargetY = 0f;
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    public void onDestroy() {
        mainHandler.post(() -> {
            if (sensorManager != null) sensorManager.unregisterListener(this);
            hideTouchOverlay();
            if (windowManager != null && overlayButton != null) {
                try { windowManager.removeViewImmediate(overlayButton); } catch (Exception ignored) { }
            }
            overlayButton = null;
            overlayShown = false;
        });
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }

    private static class StrokeState {
        GestureDescription.StrokeDescription stroke;
        float x;
        float y;
        boolean continuing;

        StrokeState() { }

        StrokeState(GestureDescription.StrokeDescription stroke, float x, float y, boolean continuing) {
            this.stroke = stroke;
            this.x = x;
            this.y = y;
            this.continuing = continuing;
        }
    }

    private static class TouchState extends StrokeState {
        final int id;
        float x;
        float y;
        float strokeX;
        float strokeY;
        boolean ending;
        boolean dispatchedBefore;

        TouchState(int id, float x, float y) {
            super();
            this.id = id;
            this.x = x;
            this.y = y;
            this.strokeX = x;
            this.strokeY = y;
        }
    }
}
