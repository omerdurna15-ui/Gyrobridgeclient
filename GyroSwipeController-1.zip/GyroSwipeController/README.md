# Gyro Swipe Controller

Android uygulaması: telefonun eğimini jiroskop + ivmeölçer ile algılar ve belirlenen açıya gelince Android AccessibilityService üzerinden yukarı kaydırma hareketi gönderir.

## Kullanım
1. APK'yi yükle.
2. Uygulamayı aç.
3. **Erişilebilirlik servisini aç** butonuna bas.
4. Listeden **Gyro Swipe Controller** servisini etkinleştir.
5. Uygulamaya geri dön ve **Jiroskop hareket kontrolü** anahtarını aç.
6. Tetikleme açısını ayarla. Varsayılan 3°.
7. Oyunu aç. Telefon nötrden yaklaşık eşik açıya kaldırıldığında tek bir yukarı swipe gönderilir.
8. Yeni swipe için telefonu yaklaşık 20° altına geri getir.

## Notlar
- Uygulama oyuna doğrudan bağlanmaz; dokunmatik hareketi Android AccessibilityService ile üretir.
- Bazı oyunlar erişilebilirlik ile üretilen hareketleri engelleyebilir.
- Telefon modeline göre sensör ekseni ters olabilir. Bu durumda `GestureAccessibilityService.kt` içindeki pitch yönünü ters çevirmek gerekebilir.
