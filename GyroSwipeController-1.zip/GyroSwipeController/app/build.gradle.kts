plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.gyroswipe"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.gyroswipe"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}

kotlinOptions {
    jvmTarget = "17"
}
