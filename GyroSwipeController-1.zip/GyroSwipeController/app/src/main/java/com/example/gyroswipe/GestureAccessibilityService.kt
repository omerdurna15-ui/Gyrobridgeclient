package com.example.gyroswipe

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Point
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sqrt

class GestureAccessibilityService : AccessibilityService(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var gyro: Sensor? = null
    private var accel: Sensor? = null
    private val handler = Handler(Looper.getMainLooper())

    private var pitch = 0.0
    private var roll = 0.0
    private var lastNs = 0L
    private var triggered = false
    private var gravityX = 0f
    private var gravityY = 0f
    private var gravityZ = 0f
    private var gravityInitialized = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyro?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        accel?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
        instance = null
        super.onDestroy()
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!enabled) return

        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val a = 0.12f
            gravityX = a * event.values[0] + (1f - a) * gravityX
            gravityY = a * event.values[1] + (1f - a) * gravityY
            gravityZ = a * event.values[2] + (1f - a) * gravityZ
            gravityInitialized = true

            if (gyro == null) {
                updateAnglesFromGravity()
            }
        }

        if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {
            val now = event.timestamp
            if (lastNs != 0L) {
                val dt = (now - lastNs) / 1_000_000_000.0
                if (dt in 0.0..0.1) {
                    // Rotate device axes into pitch/roll estimates.
                    pitch += Math.toDegrees(event.values[1].toDouble() * dt)
                    roll += Math.toDegrees(event.values[2].toDouble() * dt)

                    // Slow correction towards gravity reference avoids drift.
                    if (gravityInitialized) {
                        val gPitch = Math.toDegrees(atan2(-gravityX.toDouble(), sqrt((gravityY * gravityY + gravityZ * gravityZ).toDouble())))
                        val gRoll = Math.toDegrees(atan2(gravityY.toDouble(), gravityZ.toDouble()))
                        pitch = pitch * 0.96 + gPitch * 0.04
                        roll = roll * 0.96 + gRoll * 0.04
                    }
                    evaluateTrigger()
                }
            }
            lastNs = now
        }
    }

    private fun updateAnglesFromGravity() {
        pitch = Math.toDegrees(atan2(-gravityX.toDouble(), sqrt((gravityY * gravityY + gravityZ * gravityZ).toDouble())))
        roll = Math.toDegrees(atan2(gravityY.toDouble(), gravityZ.toDouble()))
        evaluateTrigger()
    }

    private fun evaluateTrigger() {
        val threshold = angleThreshold.toDouble()
        val upward = abs(pitch) >= threshold
        val neutral = abs(pitch) <= maxOf(0.5, threshold * 0.35)

        if (upward && !triggered) {
            triggered = true
            dispatchSwipeUp()
        } else if (neutral) {
            triggered = false
        }
    }

    private fun dispatchSwipeUp() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = Point()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealSize(size)
        val x = size.x / 2f
        val y1 = size.y * 0.70f
        val y2 = size.y * 0.30f

        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, SWIPE_DURATION_MS)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    companion object {
        @Volatile var enabled: Boolean = false
        @Volatile var angleThreshold: Float = 3f
        @Volatile private var instance: GestureAccessibilityService? = null
        private const val SWIPE_DURATION_MS = 220L
    }
}
