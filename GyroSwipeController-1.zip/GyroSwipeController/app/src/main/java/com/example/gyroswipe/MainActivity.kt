package com.example.gyroswipe

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.app.Activity

class MainActivity : Activity() {
    private lateinit var sensorManager: SensorManager
    private lateinit var sensorText: TextView
    private lateinit var thresholdText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        updateSensorStatus()
        updateAccessibilityStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Gyro Swipe Controller"
            textSize = 24f
        }
        root.addView(title)

        sensorText = TextView(this).apply {
            textSize = 16f
            setPadding(0, 24, 0, 12)
        }
        root.addView(sensorText)

        val openAccessibility = Button(this).apply {
            text = "Erişilebilirlik servisini aç"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(openAccessibility)

        val enabledSwitch = Switch(this).apply {
            text = "Jiroskop hareket kontrolü"
            isChecked = getSharedPreferences("settings", MODE_PRIVATE)
                .getBoolean("enabled", false)
            setOnCheckedChangeListener { _, checked ->
                getSharedPreferences("settings", MODE_PRIVATE)
                    .edit().putBoolean("enabled", checked).apply()
                GestureAccessibilityService.enabled = checked
            }
        }
        root.addView(enabledSwitch)

        thresholdText = TextView(this).apply { textSize = 16f }
        root.addView(thresholdText)

        val seek = SeekBar(this).apply {
            min = 1
            max = 45
            progress = getSharedPreferences("settings", MODE_PRIVATE)
                .getInt("threshold", 3)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress.coerceAtLeast(1)
                    thresholdText.text = "Tetikleme açısı: ${value}°"
                    getSharedPreferences("settings", MODE_PRIVATE)
                        .edit().putInt("threshold", value).apply()
                    GestureAccessibilityService.angleThreshold = value.toFloat()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) = Unit
                override fun onStopTrackingTouch(sb: SeekBar?) = Unit
            })
        }
        root.addView(seek)
        thresholdText.text = "Tetikleme açısı: ${seek.progress}°"

        val info = TextView(this).apply {
            text = "Telefonu normal tut. Yukarı doğru yaklaşık ayarlanan açıya kaldırınca tek bir yukarı kaydırma gönderilir. Yeniden tetiklemek için telefonu nötr konuma getir.\n\nNot: Oyunda dokunmatik hareket göndermek için Android Erişilebilirlik Servisi açık olmalıdır."
            textSize = 15f
            setPadding(0, 24, 0, 0)
        }
        root.addView(info)

        setContentView(root)
        updateSensorStatus()
        updateAccessibilityStatus()
        GestureAccessibilityService.angleThreshold = seek.progress.toFloat()
        GestureAccessibilityService.enabled = enabledSwitch.isChecked
    }

    private fun updateSensorStatus() {
        val gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        val accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorText.text = "Jiroskop: ${if (gyro != null) "VAR" else "YOK"}\nİvmeölçer: ${if (accel != null) "VAR" else "YOK"}\n"
    }

    private fun updateAccessibilityStatus() {
        val enabled = isAccessibilityServiceEnabled()
        findViewById<Button>(android.R.id.content)?.let { }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = ComponentName(this, GestureAccessibilityService::class.java)
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == expected }
    }
}
