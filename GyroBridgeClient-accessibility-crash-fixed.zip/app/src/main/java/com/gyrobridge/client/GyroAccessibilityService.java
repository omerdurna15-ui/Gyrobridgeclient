package com.gyrobridge.client;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import android.view.accessibility.AccessibilityEvent;

/**
 * Jiroskobu isteğe bağlı ekran kaydırmalarına çevirir.
 * Kamera kontrolü otomatik açılmaz; üstteki GYRO OFF/ON düğmesi ile açılır.
 */
public class GyroAccessibilityService extends AccessibilityService implements SensorEventListener {
    public static volatile GyroAccessibilityService INSTANCE;

    private static final long MIN_GESTURE_INTERVAL_MS = 28L;
    private static final long GESTURE_DURATION_MS = 22L;
    private static final float PIXELS_PER_RAD = 1200.0f;
    private static final float DEADZONE = 0.018f;
    private static final float SMOOTHING = 0.20f;
    private static final float MAX_DX = 115f;
    private static final float MAX_DY = 90f;

    private SensorManager sensorManager;
    private Sensor gyro;
    private boolean enabled = false;
    private boolean targetForeground = false;
    private String foregroundPackage = "";
    private long lastGesture = 0L;
    private float filteredX = 0f;
    private float filteredY = 0f;
    private long lastSensorTimestampNs = 0L;

    private WindowManager windowManager;
    private TextView overlayButton;
    private WindowManager.LayoutParams overlayParams;
    private boolean overlayShown = false;
    private boolean gestureInFlight = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private float downRawX, downRawY;
    private int startX, startY;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        try {
            android.accessibilityservice.AccessibilityServiceInfo info = getServiceInfo();
            if (info != null) {
                info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
                info.feedbackType = android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_GENERIC;
                info.notificationTimeout = 50;
                info.flags = android.accessibilityservice.AccessibilityServiceInfo.FLAG_DEFAULT;
                setServiceInfo(info);
            }
        } catch (Exception ignored) {}
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyro = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) : null;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        ensureOverlay();
    }

    public void ensureOverlay() {
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (!Settings.canDrawOverlays(this)) return;
        if (overlayShown && overlayButton != null) return;

        overlayButton = new TextView(this);
        overlayButton.setText("GYRO\nOFF");
        overlayButton.setTextColor(Color.WHITE);
        overlayButton.setTextSize(12f);
        overlayButton.setGravity(Gravity.CENTER);
        overlayButton.setPadding(10, 6, 10, 6);
        overlayButton.setBackground(makeBackground(false));
        overlayButton.setElevation(10f);

        overlayButton.setOnClickListener(v -> setEnabled(!enabled));
        overlayButton.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = event.getRawX();
                    downRawY = event.getRawY();
                    startX = overlayParams.x;
                    startY = overlayParams.y;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    int nx = startX + (int) (event.getRawX() - downRawX);
                    int ny = startY + (int) (event.getRawY() - downRawY);
                    overlayParams.x = nx;
                    overlayParams.y = ny;
                    try { windowManager.updateViewLayout(overlayButton, overlayParams); } catch (Exception ignored) {}
                    return true;
                default:
                    return false;
            }
        });

        int type = android.os.Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.END;
        overlayParams.x = 18;
        overlayParams.y = 110;

        try {
            windowManager.addView(overlayButton, overlayParams);
            overlayShown = true;
        } catch (Exception e) {
            Toast.makeText(this, "Kamera tuşu gösterilemedi: Üstte gösterme iznini kontrol et.", Toast.LENGTH_SHORT).show();
        }
    }

    private GradientDrawable makeBackground(boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(on ? Color.rgb(20, 155, 90) : Color.rgb(70, 75, 82));
        bg.setCornerRadius(28f);
        bg.setStroke(2, Color.WHITE);
        return bg;
    }

    public void setEnabled(boolean value) {
        enabled = value;
        filteredX = filteredY = 0f;
        lastGesture = 0L;
        lastSensorTimestampNs = 0L;
        if (sensorManager != null && gyro != null) {
            try {
                sensorManager.unregisterListener(this);
                if (enabled) sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
            } catch (Exception e) {
                enabled = false;
                Toast.makeText(this, "Jiroskop başlatılamadı: " + e.getClass().getSimpleName(), Toast.LENGTH_SHORT).show();
            }
        }
        updateOverlayText();
        Toast.makeText(this, enabled ? "Gyro kamera AÇIK" : "Gyro kamera KAPALI", Toast.LENGTH_SHORT).show();
    }

    public boolean isEnabledByUser() { return enabled; }

    private void updateOverlayText() {
        if (overlayButton == null) return;
        overlayButton.setText(enabled ? "GYRO\nON" : "GYRO\nOFF");
        overlayButton.setBackground(makeBackground(enabled));
    }

    /** Sends one small visible swipe for testing. */
    public void sendTestSwipe() {
        if (!targetForeground) {
            Toast.makeText(this, "Önce test yapılacak uygulamaya geç.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (gestureInFlight) return;
        gestureInFlight = true;
        mainHandler.post(() -> {
            try {
                boolean accepted = dispatchCameraSwipe(80f, 0f, new AccessibilityService.GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription g) { gestureInFlight = false; }
                    @Override public void onCancelled(GestureDescription g) { gestureInFlight = false; }
                });
                if (!accepted) gestureInFlight = false;
            } catch (Exception e) {
                gestureInFlight = false;
            }
        });
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkg = event.getPackageName();
        foregroundPackage = pkg == null ? "" : pkg.toString();
        targetForeground = !foregroundPackage.equals(getPackageName()) && !foregroundPackage.isEmpty();
    }

    @Override public void onInterrupt() {
        gestureInFlight = false;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!enabled || !targetForeground || event.sensor.getType() != Sensor.TYPE_GYROSCOPE) return;

        long now = SystemClock.uptimeMillis();
        if (now - lastGesture < MIN_GESTURE_INTERVAL_MS) return;

        // Minecraft yatay (landscape) tutulduğu için telefon eksenlerini 90° döndürüyoruz.
        // Yeni eşleme: telefon sağa/sola -> kamera sağa/sola,
        // telefon yukarı/aşağı -> kamera yukarı/aşağı.
        float horizontal = -event.values[0];
        float vertical = event.values[1];

        if (Math.abs(horizontal) < DEADZONE) horizontal = 0f;
        if (Math.abs(vertical) < DEADZONE) vertical = 0f;

        filteredX += (horizontal - filteredX) * SMOOTHING;
        filteredY += (vertical - filteredY) * SMOOTHING;

        float dt = 0.016f;
        if (lastSensorTimestampNs != 0L) {
            dt = (event.timestamp - lastSensorTimestampNs) / 1_000_000_000f;
            if (dt <= 0f || dt > 0.05f) dt = 0.016f;
        }
        lastSensorTimestampNs = event.timestamp;

        // Integrate angular velocity over the frame interval. This avoids
        // sensitivity depending on sensor callback frequency and makes
        // motion much smoother than multiplying raw rad/s directly.
        float dx = clamp(filteredX * dt * PIXELS_PER_RAD, -MAX_DX, MAX_DX);
        float dy = clamp(filteredY * dt * PIXELS_PER_RAD, -MAX_DY, MAX_DY);
        if (Math.abs(dx) < 0.6f && Math.abs(dy) < 0.6f) return;
        if (gestureInFlight) return;

        gestureInFlight = true;
        final float fdx = dx;
        final float fdy = dy;
        mainHandler.post(() -> {
            try {
                if (!enabled || !targetForeground) {
                    gestureInFlight = false;
                    return;
                }
                boolean accepted = dispatchCameraSwipe(fdx, fdy, new AccessibilityService.GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription gestureDescription) {
                        gestureInFlight = false;
                        lastGesture = SystemClock.uptimeMillis();
                    }
                    @Override public void onCancelled(GestureDescription gestureDescription) {
                        gestureInFlight = false;
                        lastGesture = SystemClock.uptimeMillis();
                    }
                });
                if (!accepted) {
                    gestureInFlight = false;
                    lastGesture = SystemClock.uptimeMillis();
                }
            } catch (Exception e) {
                gestureInFlight = false;
                lastGesture = SystemClock.uptimeMillis();
            }
        });
    }

    private boolean dispatchCameraSwipe(float dx, float dy, AccessibilityService.GestureResultCallback callback) {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * 0.72f;
        float y = dm.heightPixels * 0.52f;

        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x + dx, y + dy);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, GESTURE_DURATION_MS))
                .build();
        return dispatchGesture(gesture, callback, mainHandler);
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    public void onDestroy() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        if (windowManager != null && overlayButton != null) {
            try { windowManager.removeView(overlayButton); } catch (Exception ignored) {}
        }
        overlayButton = null;
        overlayShown = false;
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }
}
