package com.gyrobridge.client;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.accessibility.AccessibilityEvent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Virtual multi-touch bridge.
 *
 * When GYRO is ON, the service places one synthetic camera finger in an empty
 * part of the Minecraft screen and continuously moves it with the gyro.
 * A transparent full-screen overlay captures the user's real touches and
 * replays those touches to the foreground app as additional pointers.
 *
 * The important difference from the earlier versions is that ALL touches are
 * replayed by the same gesture stream. We no longer inject a separate gyro
 * gesture that cancels the user's joystick/button gesture.
 */
public class GyroAccessibilityService extends AccessibilityService implements SensorEventListener {
    public static volatile GyroAccessibilityService INSTANCE;

    private static final long SEGMENT_MS = 16L;
    private static final float PIXELS_PER_RAD = 4200f;
    private static final float DEADZONE = 0.00025f;
    private static final float SMOOTHING = 0.22f;
    private static final float MAX_DT = 0.05f;
    private static final float GYRO_MAX_STEP = 18f;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Map<Integer, TouchPoint> userTouches = new LinkedHashMap<>();

    private SensorManager sensorManager;
    private Sensor gyro;
    private WindowManager windowManager;
    private FrameLayout buttonRoot;
    private FrameLayout captureRoot;
    private TextView gyroButton;
    private WindowManager.LayoutParams buttonParams;
    private WindowManager.LayoutParams captureParams;
    private boolean buttonShown;
    private boolean captureShown;
    private boolean enabled;
    private boolean targetForeground;

    private float filteredX;
    private float filteredY;
    private float gyroX;
    private float gyroY;
    private long lastSensorTimestampNs;
    private boolean dispatchBusy;
    private GestureDescription.StrokeDescription gyroStroke;


    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyro = sensorManager == null ? null : sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        ensureOverlay();
    }

    /**
     * Important: the old version created a full-screen touchable overlay as
     * soon as the accessibility service connected. That meant enabling the
     * accessibility service immediately covered the whole Minecraft screen
     * and swallowed every touch, even while GYRO was OFF.
     *
     * This version keeps ONLY a small toggle window alive while OFF. The
     * full-screen capture overlay is created only after the user explicitly
     * turns GYRO ON.
     */
    public void ensureOverlay() {
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (!Settings.canDrawOverlays(this)) return;
        if (buttonShown && buttonRoot != null) return;

        buttonRoot = new FrameLayout(this);
        buttonRoot.setBackgroundColor(Color.TRANSPARENT);
        buttonRoot.setClickable(false);
        buttonRoot.setFocusable(false);

        gyroButton = new TextView(this);
        gyroButton.setText("GYRO\nOFF");
        gyroButton.setTextColor(Color.WHITE);
        gyroButton.setTextSize(12f);
        gyroButton.setGravity(Gravity.CENTER);
        gyroButton.setPadding(11, 7, 11, 7);
        gyroButton.setBackground(makeBackground(false));
        gyroButton.setElevation(20f);
        gyroButton.setClickable(true);
        gyroButton.setOnClickListener(v -> setEnabled(!enabled));

        final float[] downX = new float[1];
        final float[] downY = new float[1];
        final int[] startX = new int[1];
        final int[] startY = new int[1];
        gyroButton.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX[0] = event.getRawX();
                    downY[0] = event.getRawY();
                    startX[0] = buttonParams == null ? 0 : buttonParams.x;
                    startY[0] = buttonParams == null ? 0 : buttonParams.y;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    if (buttonParams != null && windowManager != null) {
                        buttonParams.x = startX[0] + (int) (event.getRawX() - downX[0]);
                        buttonParams.y = startY[0] + (int) (event.getRawY() - downY[0]);
                        try { windowManager.updateViewLayout(buttonRoot, buttonParams); } catch (Exception ignored) {}
                    }
                    return true;
                default:
                    return false;
            }
        });

        FrameLayout.LayoutParams btnLp = new FrameLayout.LayoutParams(
                dp(78), dp(60), Gravity.TOP | Gravity.END);
        btnLp.topMargin = dp(108);
        btnLp.rightMargin = dp(18);
        buttonRoot.addView(gyroButton, btnLp);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        buttonParams = new WindowManager.LayoutParams(
                dp(78), dp(60), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        buttonParams.gravity = Gravity.TOP | Gravity.END;

        try {
            windowManager.addView(buttonRoot, buttonParams);
            buttonShown = true;
        } catch (Exception e) {
            Toast.makeText(this, "Üstte gösterme iznini kontrol et.", Toast.LENGTH_SHORT).show();
        }
    }

    private void startCaptureOverlay() {
        if (captureShown || windowManager == null) return;
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        captureRoot = new FrameLayout(this);
        captureRoot.setBackgroundColor(Color.TRANSPARENT);
        captureRoot.setClickable(true);
        captureRoot.setFocusable(false);
        captureRoot.setOnTouchListener((v, event) -> {
            // Never intercept the toggle button's area.
            if (isInsideButton(event.getRawX(), event.getRawY())) return false;
            handleUserTouch(event);
            return true;
        });

        captureParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        captureParams.gravity = Gravity.TOP | Gravity.START;

        try {
            windowManager.addView(captureRoot, captureParams);
            captureShown = true;
        } catch (Exception e) {
            captureRoot = null;
            captureParams = null;
            Toast.makeText(this, "Dokunma köprüsü başlatılamadı.", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopCaptureOverlay() {
        if (!captureShown || captureRoot == null || windowManager == null) return;
        try { windowManager.removeView(captureRoot); } catch (Exception ignored) {}
        captureShown = false;
        captureRoot = null;
        captureParams = null;
        for (TouchPoint p : userTouches.values()) p.upPending = true;
        userTouches.clear();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private boolean isInsideButton(float rawX, float rawY) {
        if (gyroButton == null) return false;
        int[] loc = new int[2];
        gyroButton.getLocationOnScreen(loc);
        return rawX >= loc[0] && rawX <= loc[0] + gyroButton.getWidth()
                && rawY >= loc[1] && rawY <= loc[1] + gyroButton.getHeight();
    }

    private GradientDrawable makeBackground(boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(on ? Color.rgb(25, 160, 90) : Color.rgb(70, 75, 82));
        bg.setCornerRadius(dp(28));
        bg.setStroke(dp(2), Color.WHITE);
        return bg;
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        filteredX = filteredY = 0f;
        gyroX = gyroY = 0f;
        lastSensorTimestampNs = 0L;
        gyroStroke = null;

        if (sensorManager != null && gyro != null) {
            sensorManager.unregisterListener(this);
            if (enabled) sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
        }

        if (enabled) {
            startCaptureOverlay();
            startDispatchLoop();
        } else {
            stopCaptureOverlay();
        }

        updateOverlayText();
        if (!enabled) pumpDispatch();
        Toast.makeText(this, enabled ? "Gyro + touch bridge AÇIK" : "Gyro + touch bridge KAPALI", Toast.LENGTH_SHORT).show();
    }

    private void updateOverlayText() {
        if (gyroButton == null) return;
        gyroButton.setText(enabled ? "GYRO\nON" : "GYRO\nOFF");
        gyroButton.setBackground(makeBackground(enabled));
    }

    public void sendTestSwipe() {
        if (!targetForeground) {
            Toast.makeText(this, "Önce test yapılacak uygulamaya geç.", Toast.LENGTH_SHORT).show();
            return;
        }
        ensureGyroAnchor();
        Path path = new Path();
        path.moveTo(gyroX, gyroY);
        path.lineTo(gyroX + 80f, gyroY);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 250);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(stroke)
                .build();
        dispatchGesture(gesture, new GestureResultCallback() {}, mainHandler);
    }

    private void handleUserTouch(MotionEvent event) {
        int action = event.getActionMasked();
        int actionIndex = event.getActionIndex();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int id = event.getPointerId(actionIndex);
                TouchPoint p = new TouchPoint(id, event.getX(actionIndex), event.getY(actionIndex));
                userTouches.put(id, p);
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int id = event.getPointerId(i);
                    TouchPoint p = userTouches.get(id);
                    if (p != null) {
                        p.x = event.getX(i);
                        p.y = event.getY(i);
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                int id = event.getPointerId(actionIndex);
                TouchPoint p = userTouches.get(id);
                if (p != null) {
                    p.x = event.getX(actionIndex);
                    p.y = event.getY(actionIndex);
                    p.upPending = true;
                }
                break;
            }
            case MotionEvent.ACTION_CANCEL:
                for (TouchPoint p : userTouches.values()) p.upPending = true;
                break;
        }
        pumpDispatch();
    }

    private void startDispatchLoop() {
        mainHandler.removeCallbacks(dispatchRunnable);
        mainHandler.post(dispatchRunnable);
    }

    private final Runnable dispatchRunnable = new Runnable() {
        @Override public void run() {
            pumpDispatch();
            if (enabled || !userTouches.isEmpty()) {
                mainHandler.postDelayed(this, 2L);
            }
        }
    };

    private void pumpDispatch() {
        if (dispatchBusy || !targetForeground) return;
        if (!enabled && userTouches.isEmpty()) return;

        GestureDescription.Builder builder = new GestureDescription.Builder();
        boolean hasAny = false;
        ArrayList<Integer> completedIds = new ArrayList<>();

        // 1) Continuous virtual camera pointer.
        if (enabled) {
            ensureGyroAnchor();
            float nx = clamp(gyroX, 0.55f * screenWidth(), 0.94f * screenWidth());
            float ny = clamp(gyroY, 0.18f * screenHeight(), 0.82f * screenHeight());
            Path p = new Path();
            p.moveTo(gyroX, gyroY);
            p.lineTo(nx, ny);
            boolean cont = true;
            try {
                GestureDescription.StrokeDescription next;
                if (gyroStroke == null) {
                    next = new GestureDescription.StrokeDescription(p, 0, SEGMENT_MS, cont);
                } else {
                    next = gyroStroke.continueStroke(p, 0, SEGMENT_MS, cont);
                }
                builder.addStroke(next);
                gyroStroke = next;
                gyroX = nx;
                gyroY = ny;
                hasAny = true;
            } catch (IllegalArgumentException ignored) {
                gyroStroke = null;
            }
        }

        // 2) Replay all real user pointers in the SAME GestureDescription.
        for (TouchPoint t : new ArrayList<>(userTouches.values())) {
            Path path = new Path();
            path.moveTo(t.lastX, t.lastY);
            path.lineTo(t.x, t.y);
            boolean cont = !t.upPending;
            try {
                GestureDescription.StrokeDescription next;
                if (t.stroke == null) {
                    next = new GestureDescription.StrokeDescription(path, 0, SEGMENT_MS, cont);
                } else {
                    next = t.stroke.continueStroke(path, 0, SEGMENT_MS, cont);
                }
                builder.addStroke(next);
                t.stroke = next;
                t.lastX = t.x;
                t.lastY = t.y;
                hasAny = true;
                if (t.upPending) completedIds.add(t.id);
            } catch (IllegalArgumentException ignored) {
                t.stroke = null;
                if (t.upPending) completedIds.add(t.id);
            }
        }

        if (!hasAny) return;

        GestureDescription gesture = builder.build();
        dispatchBusy = true;
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription description) {
                dispatchBusy = false;
                // Remove pointers that ended in this segment.
                for (Integer id : new ArrayList<>(completedIds)) {
                    TouchPoint p = userTouches.get(id);
                    if (p != null && p.upPending) userTouches.remove(id);
                }
                // If gyro was turned off, end its current stroke next cycle.
                if (!enabled) gyroStroke = null;
                pumpDispatch();
            }

            @Override public void onCancelled(GestureDescription description) {
                dispatchBusy = false;
                // Keep the logical pointers alive and retry the same state.
                for (TouchPoint p : userTouches.values()) p.stroke = null;
                gyroStroke = null;
                pumpDispatch();
            }
        }, mainHandler);

        if (!accepted) {
            dispatchBusy = false;
            for (TouchPoint p : userTouches.values()) p.stroke = null;
            gyroStroke = null;
        }
    }

    private void ensureGyroAnchor() {
        if (Float.isNaN(gyroX) || gyroX <= 0f) {
            gyroX = 0.78f * screenWidth();
            gyroY = 0.50f * screenHeight();
        }
    }

    private void resetGyroAnchor() {
        gyroX = 0.78f * screenWidth();
        gyroY = 0.50f * screenHeight();
        gyroStroke = null;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkg = event.getPackageName();
        String foreground = pkg == null ? "" : pkg.toString();
        boolean was = targetForeground;
        targetForeground = !foreground.isEmpty() && !foreground.equals(getPackageName());
        if (targetForeground && !was) {
            resetGyroAnchor();
            pumpDispatch();
        }
        if (!targetForeground && was) {
            for (TouchPoint p : userTouches.values()) p.upPending = true;
            gyroStroke = null;
        }
    }

    @Override public void onInterrupt() { }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (!enabled || !targetForeground || e.sensor.getType() != Sensor.TYPE_GYROSCOPE) return;
        long ts = e.timestamp;
        float dt = 0.016f;
        if (lastSensorTimestampNs != 0L) {
            dt = (ts - lastSensorTimestampNs) / 1_000_000_000f;
            if (dt <= 0f || dt > MAX_DT) dt = 0.016f;
        }
        lastSensorTimestampNs = ts;

        float horizontal = -e.values[0];
        float vertical = e.values[1];
        if (Math.abs(horizontal) < DEADZONE) horizontal = 0f;
        if (Math.abs(vertical) < DEADZONE) vertical = 0f;

        float speed = Math.min(1f, (float) Math.sqrt(horizontal * horizontal + vertical * vertical) / 2.0f);
        float adaptive = SMOOTHING - 0.10f * speed;
        if (adaptive < 0.10f) adaptive = 0.10f;
        filteredX += (horizontal - filteredX) * adaptive;
        filteredY += (vertical - filteredY) * adaptive;

        float dx = filteredX * dt * PIXELS_PER_RAD;
        float dy = filteredY * dt * PIXELS_PER_RAD;
        dx = clamp(dx, -GYRO_MAX_STEP, GYRO_MAX_STEP);
        dy = clamp(dy, -GYRO_MAX_STEP, GYRO_MAX_STEP);

        gyroX += dx;
        gyroY += dy;
        gyroX = clamp(gyroX, 0.55f * screenWidth(), 0.94f * screenWidth());
        gyroY = clamp(gyroY, 0.18f * screenHeight(), 0.82f * screenHeight());
        pumpDispatch();
    }

    private int screenWidth() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int screenHeight() {
        return getResources().getDisplayMetrics().heightPixels;
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    public void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        if (sensorManager != null) sensorManager.unregisterListener(this);
        try {
            if (captureRoot != null && captureShown && windowManager != null) windowManager.removeView(captureRoot);
        } catch (Exception ignored) { }
        try {
            if (buttonRoot != null && buttonShown && windowManager != null) windowManager.removeView(buttonRoot);
        } catch (Exception ignored) { }
        captureShown = false;
        buttonShown = false;
        captureRoot = null;
        buttonRoot = null;
        INSTANCE = null;
        super.onDestroy();
    }

    private static class TouchPoint {
        final int id;
        float x;
        float y;
        float lastX;
        float lastY;
        boolean upPending;
        GestureDescription.StrokeDescription stroke;

        TouchPoint(int id, float x, float y) {
            this.id = id;
            this.x = this.lastX = x;
            this.y = this.lastY = y;
        }
    }
}
