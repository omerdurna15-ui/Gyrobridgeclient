package com.gyrobridge.client;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import android.view.accessibility.AccessibilityEvent;

/**
 * Jiroskobu isteğe bağlı ekran kaydırmalarına çevirir.
 * Kamera kontrolü otomatik açılmaz; üstteki GYRO OFF/ON düğmesi ile açılır.
 */
public class GyroAccessibilityService extends AccessibilityService implements SensorEventListener {
    public static volatile GyroAccessibilityService INSTANCE;

    private static final long MIN_GESTURE_INTERVAL_MS = 38L;
    private static final long GESTURE_DURATION_MS = 42L;
    private static final float PIXELS_PER_RAD = 2100.0f;
    private static final float DEADZONE = 0.0035f;
    private static final float SMOOTHING = 0.28f;
    private static final float MAX_DX = 85f;
    private static final float MAX_DY = 70f;
    private static final float MAX_DT_S = 0.05f;

    private SensorManager sensorManager;
    private Sensor gyro;
    private boolean enabled = false;
    private boolean targetForeground = false;
    private String foregroundPackage = "";
    private long lastGesture = 0L;
    private float filteredX = 0f;
    private float filteredY = 0f;
    private float accumulatedDx = 0f;
    private float accumulatedDy = 0f;
    private long lastSensorTimestampNs = 0L;

    private WindowManager windowManager;
    private TextView overlayButton;
    private WindowManager.LayoutParams overlayParams;
    private boolean overlayShown = false;
    private float downRawX, downRawY;
    private int startX, startY;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyro = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) : null;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        ensureOverlay();
    }

    public void ensureOverlay() {
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (!Settings.canDrawOverlays(this)) return;
        if (overlayShown && overlayButton != null) return;

        overlayButton = new TextView(this);
        overlayButton.setText("GYRO\nOFF");
        overlayButton.setTextColor(Color.WHITE);
        overlayButton.setTextSize(12f);
        overlayButton.setGravity(Gravity.CENTER);
        overlayButton.setPadding(10, 6, 10, 6);
        overlayButton.setBackground(makeBackground(false));
        overlayButton.setElevation(10f);

        overlayButton.setOnClickListener(v -> setEnabled(!enabled));
        overlayButton.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = event.getRawX();
                    downRawY = event.getRawY();
                    startX = overlayParams.x;
                    startY = overlayParams.y;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    int nx = startX + (int) (event.getRawX() - downRawX);
                    int ny = startY + (int) (event.getRawY() - downRawY);
                    overlayParams.x = nx;
                    overlayParams.y = ny;
                    try { windowManager.updateViewLayout(overlayButton, overlayParams); } catch (Exception ignored) {}
                    return true;
                default:
                    return false;
            }
        });

        int type = android.os.Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.END;
        overlayParams.x = 18;
        overlayParams.y = 110;

        try {
            windowManager.addView(overlayButton, overlayParams);
            overlayShown = true;
        } catch (Exception e) {
            Toast.makeText(this, "Kamera tuşu gösterilemedi: Üstte gösterme iznini kontrol et.", Toast.LENGTH_SHORT).show();
        }
    }

    private GradientDrawable makeBackground(boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(on ? Color.rgb(20, 155, 90) : Color.rgb(70, 75, 82));
        bg.setCornerRadius(28f);
        bg.setStroke(2, Color.WHITE);
        return bg;
    }

    public void setEnabled(boolean value) {
        enabled = value;
        filteredX = filteredY = 0f;
        accumulatedDx = accumulatedDy = 0f;
        lastSensorTimestampNs = 0L;
        lastGesture = 0L;
        if (sensorManager != null && gyro != null) {
            sensorManager.unregisterListener(this);
            if (enabled) sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
        }
        updateOverlayText();
        Toast.makeText(this, enabled ? "Gyro kamera AÇIK" : "Gyro kamera KAPALI", Toast.LENGTH_SHORT).show();
    }

    public boolean isEnabledByUser() { return enabled; }

    private void updateOverlayText() {
        if (overlayButton == null) return;
        overlayButton.setText(enabled ? "GYRO\nON" : "GYRO\nOFF");
        overlayButton.setBackground(makeBackground(enabled));
    }

    /** Sends one small visible swipe for testing. */
    public void sendTestSwipe() {
        if (!targetForeground) {
            Toast.makeText(this, "Önce test yapılacak uygulamaya geç.", Toast.LENGTH_SHORT).show();
            return;
        }
        dispatchCameraSwipe(80f, 0f);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkg = event.getPackageName();
        foregroundPackage = pkg == null ? "" : pkg.toString();
        targetForeground = !foregroundPackage.equals(getPackageName()) && !foregroundPackage.isEmpty();
    }

    @Override public void onInterrupt() { }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!enabled || !targetForeground || event.sensor.getType() != Sensor.TYPE_GYROSCOPE) return;

        long ts = event.timestamp;
        float dt = 0.016f;
        if (lastSensorTimestampNs != 0L) {
            dt = (ts - lastSensorTimestampNs) / 1_000_000_000f;
            if (dt <= 0f || dt > MAX_DT_S) dt = 0.016f;
        }
        lastSensorTimestampNs = ts;

        // Gyroscope values are angular velocity (rad/s). Integrate over dt
        // so movement is frame-rate independent. Landscape axes are rotated 90°.
        float horizontalRate = -event.values[0];
        float verticalRate = event.values[1];

        if (Math.abs(horizontalRate) < DEADZONE) horizontalRate = 0f;
        if (Math.abs(verticalRate) < DEADZONE) verticalRate = 0f;

        filteredX += (horizontalRate - filteredX) * SMOOTHING;
        filteredY += (verticalRate - filteredY) * SMOOTHING;

        accumulatedDx += filteredX * dt * PIXELS_PER_RAD;
        accumulatedDy += filteredY * dt * PIXELS_PER_RAD;

        long now = SystemClock.uptimeMillis();
        if (now - lastGesture < MIN_GESTURE_INTERVAL_MS) return;

        float dx = clamp(accumulatedDx, -MAX_DX, MAX_DX);
        float dy = clamp(accumulatedDy, -MAX_DY, MAX_DY);
        if (Math.abs(dx) < 1.5f && Math.abs(dy) < 1.5f) return;

        if (dispatchCameraSwipe(dx, dy)) {
            accumulatedDx -= dx;
            accumulatedDy -= dy;
            lastGesture = now;
        } else {
            // If Android rejects the gesture, don't spin-retry every sensor event.
            lastGesture = now;
            accumulatedDx = clamp(accumulatedDx, -MAX_DX, MAX_DX);
            accumulatedDy = clamp(accumulatedDy, -MAX_DY, MAX_DY);
        }
    }

    private boolean dispatchCameraSwipe(float dx, float dy) {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * 0.78f;
        float y = dm.heightPixels * 0.52f;

        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x + dx, y + dy);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, GESTURE_DURATION_MS))
                .build();
        return dispatchGesture(gesture, null, null);
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    public void onDestroy() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        if (windowManager != null && overlayButton != null) {
            try { windowManager.removeView(overlayButton); } catch (Exception ignored) {}
        }
        overlayButton = null;
        overlayShown = false;
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }
}
