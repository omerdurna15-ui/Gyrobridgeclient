# GyroBridgeClient – smoother camera build

This build integrates gyro angular velocity over the real sensor time delta (`dt`) and batches small camera movement into short swipe gestures. This avoids dropping tiny movements due to integer rounding and makes the motion less dependent on sensor callback timing.

The overlay GYRO ON/OFF button remains unchanged.

Note: Android Accessibility `dispatchGesture()` can interfere with simultaneous user touch gestures. This build reduces gesture spam, but it cannot guarantee perfect joystick coexistence.
