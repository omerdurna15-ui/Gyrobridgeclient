# GyroBridgeClient — Continuous Gyro + Multi-touch Bridge

Bu sürüm iki şeyi aynı anda hedefler:

1. Jiroskop verisini gerçek `dt` ile kameraya dönüştürmek.
2. GYRO açıkken kullanıcı dokunuşlarını şeffaf tam ekran katmandan alıp Minecraft'a tekrar göndermek ve jiroskopu ayrı bir sürekli stroke olarak aynı gesture zincirine katmak.

## Kullanım

- Erişilebilirlik iznini aç.
- "Üstte gösterme" iznini aç.
- Uygulamaya dön; `GYRO OFF` yüzen düğmesi görünür.
- Minecraft'a gir.
- `GYRO OFF` → `GYRO ON`.
- Bu sırada joystick ve diğer parmak dokunuşları köprü üzerinden iletilir.
- `GYRO OFF` ile tam ekran dokunma katmanı kaldırılır ve normal dokunma geri gelir.

## Akıcılık

Jiroskop açısal hızını timestamp farkıyla entegre eder, küçük hareketleri yuvarlamaz, hafif düşük geçiren filtre uygular ve gesture çağrılarını seri hale getirir.

## Bilinen sınır

Bu yaklaşım AccessibilityService'in gesture API'sini kullanır. Android, devam eden stroke'ların `continueStroke()` ile korunmasına izin verir ve tek bir GestureDescription içinde birden fazla stroke destekler. Cihaz/ROM veya oyunun kendi dokunma işleme davranışı nedeniyle küçük farklar olabilir.
