package com.gyrobridge.client;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import android.view.accessibility.AccessibilityEvent;

/**
 * Gyroscope camera mode using a virtual finger anchor.
 * Instead of sending many unrelated taps, the service chains short drag segments
 * from one virtual touch position to the next. The anchor lives in the camera area.
 */
public class GyroAccessibilityService extends AccessibilityService implements SensorEventListener {
    public static volatile GyroAccessibilityService INSTANCE;

    private static final long SEGMENT_DURATION_MS = 70L;
    private static final float PIXELS_PER_RAD = 2500.0f;
    private static final float DEADZONE = 0.0018f;
    private static final float SMOOTHING = 0.42f;
    private static final float MAX_SEGMENT_DX = 34f;
    private static final float MAX_SEGMENT_DY = 30f;
    private static final float MAX_DT_S = 0.05f;
    private static final float MIN_MOVE_PX = 0.6f;

    private SensorManager sensorManager;
    private Sensor gyro;
    private boolean enabled = false;
    private boolean targetForeground = false;

    private float filteredX = 0f;
    private float filteredY = 0f;
    private float accumulatedDx = 0f;
    private float accumulatedDy = 0f;
    private long lastSensorTimestampNs = 0L;

    // Virtual finger position. Reset to a camera-area anchor when the mode starts.
    private float fingerX = Float.NaN;
    private float fingerY = Float.NaN;
    private GestureDescription.StrokeDescription activeStroke = null;
    private boolean gestureBusy = false;
    private boolean pendingRelease = false;

    private WindowManager windowManager;
    private TextView overlayButton;
    private WindowManager.LayoutParams overlayParams;
    private boolean overlayShown = false;
    private float downRawX, downRawY;
    private int startX, startY;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        INSTANCE = this;
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyro = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) : null;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        ensureOverlay();
    }

    public void ensureOverlay() {
        if (windowManager == null) windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (!Settings.canDrawOverlays(this)) return;
        if (overlayShown && overlayButton != null) return;

        overlayButton = new TextView(this);
        overlayButton.setText("GYRO\nOFF");
        overlayButton.setTextColor(Color.WHITE);
        overlayButton.setTextSize(12f);
        overlayButton.setGravity(Gravity.CENTER);
        overlayButton.setPadding(10, 6, 10, 6);
        overlayButton.setBackground(makeBackground(false));
        overlayButton.setElevation(10f);

        overlayButton.setOnClickListener(v -> setEnabled(!enabled));
        overlayButton.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = event.getRawX();
                    downRawY = event.getRawY();
                    startX = overlayParams.x;
                    startY = overlayParams.y;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    int nx = startX + (int) (event.getRawX() - downRawX);
                    int ny = startY + (int) (event.getRawY() - downRawY);
                    overlayParams.x = nx;
                    overlayParams.y = ny;
                    try { windowManager.updateViewLayout(overlayButton, overlayParams); } catch (Exception ignored) {}
                    return true;
                default:
                    return false;
            }
        });

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.END;
        overlayParams.x = 18;
        overlayParams.y = 110;

        try {
            windowManager.addView(overlayButton, overlayParams);
            overlayShown = true;
        } catch (Exception e) {
            Toast.makeText(this, "Kamera tuşu gösterilemedi: Üstte gösterme iznini kontrol et.", Toast.LENGTH_SHORT).show();
        }
    }

    private GradientDrawable makeBackground(boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(on ? Color.rgb(20, 155, 90) : Color.rgb(70, 75, 82));
        bg.setCornerRadius(28f);
        bg.setStroke(2, Color.WHITE);
        return bg;
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;

        if (!value) {
            // End the currently held virtual finger gracefully on the next boundary.
            pendingRelease = true;
        }

        enabled = value;
        filteredX = filteredY = 0f;
        accumulatedDx = accumulatedDy = 0f;
        lastSensorTimestampNs = 0L;

        if (sensorManager != null && gyro != null) {
            sensorManager.unregisterListener(this);
            if (enabled) sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
        }

        if (enabled) {
            resetFingerAnchor();
            activeStroke = null;
            gestureBusy = false;
            pendingRelease = false;
            if (targetForeground) dispatchNextContinuousStroke();
        }

        updateOverlayText();
        Toast.makeText(this, enabled ? "Gyro kamera AÇIK" : "Gyro kamera KAPALI", Toast.LENGTH_SHORT).show();
    }

    public boolean isEnabledByUser() { return enabled; }

    private void updateOverlayText() {
        if (overlayButton == null) return;
        overlayButton.setText(enabled ? "GYRO\nON" : "GYRO\nOFF");
        overlayButton.setBackground(makeBackground(enabled));
    }

    public void sendTestSwipe() {
        if (!targetForeground) {
            Toast.makeText(this, "Önce test yapılacak uygulamaya geç.", Toast.LENGTH_SHORT).show();
            return;
        }
        resetFingerAnchor();
        activeStroke = null;
        gestureBusy = false;
        pendingRelease = false;
        accumulatedDx = 55f;
        dispatchNextContinuousStroke();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkg = event.getPackageName();
        String foreground = pkg == null ? "" : pkg.toString();
        boolean wasTarget = targetForeground;
        targetForeground = !foreground.equals(getPackageName()) && !foreground.isEmpty();

        if (enabled && wasTarget && !targetForeground) {
            // Finish the held finger when leaving the target app.
            pendingRelease = true;
        }

        if (enabled && targetForeground && !wasTarget) {
            resetFingerAnchor();
            activeStroke = null;
            gestureBusy = false;
            pendingRelease = false;
            dispatchNextContinuousStroke();
        }
    }

    @Override public void onInterrupt() { }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!enabled || !targetForeground || event.sensor.getType() != Sensor.TYPE_GYROSCOPE) return;

        long ts = event.timestamp;
        float dt = 0.016f;
        if (lastSensorTimestampNs != 0L) {
            dt = (ts - lastSensorTimestampNs) / 1_000_000_000f;
            if (dt <= 0f || dt > MAX_DT_S) dt = 0.016f;
        }
        lastSensorTimestampNs = ts;

        // Landscape mapping: physical tilt -> Minecraft camera directions.
        float horizontalRate = -event.values[0];
        float verticalRate = event.values[1];

        if (Math.abs(horizontalRate) < DEADZONE) horizontalRate = 0f;
        if (Math.abs(verticalRate) < DEADZONE) verticalRate = 0f;

        filteredX += (horizontalRate - filteredX) * SMOOTHING;
        filteredY += (verticalRate - filteredY) * SMOOTHING;

        accumulatedDx += filteredX * dt * PIXELS_PER_RAD;
        accumulatedDy += filteredY * dt * PIXELS_PER_RAD;

        pumpGesture();
    }

    private void pumpGesture() {
        if (!gestureBusy) {
            dispatchNextContinuousStroke();
        }
    }

    /**
     * Maintains a single virtual finger continuously held down. Android API 26+
     * supports continueStroke(), which keeps the pointer down between gesture
     * submissions instead of lifting and pressing again.
     */
    private void dispatchNextContinuousStroke() {
        if (!targetForeground && !pendingRelease) return;

        ensureFingerAnchor();

        float dx = clamp(accumulatedDx, -MAX_SEGMENT_DX, MAX_SEGMENT_DX);
        float dy = clamp(accumulatedDy, -MAX_SEGMENT_DY, MAX_SEGMENT_DY);
        boolean releasing = pendingRelease || !enabled || !targetForeground;

        // Keep the pointer stationary when there is no gyro motion. The finger remains down.
        if (!releasing && Math.abs(dx) < MIN_MOVE_PX && Math.abs(dy) < MIN_MOVE_PX) {
            dx = 0f;
            dy = 0f;
        }

        float endX = fingerX + dx;
        float endY = fingerY + dy;

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float margin = 80f;
        endX = clamp(endX, margin, dm.widthPixels - margin);
        endY = clamp(endY, margin, dm.heightPixels - margin);

        Path path = new Path();
        path.moveTo(fingerX, fingerY);
        path.lineTo(endX, endY);

        final long duration = (dx == 0f && dy == 0f) ? 120L : SEGMENT_DURATION_MS;
        final boolean willContinue = !releasing;

        final GestureDescription.StrokeDescription nextStroke;
        try {
            if (activeStroke == null) {
                nextStroke = new GestureDescription.StrokeDescription(path, 0L, duration, willContinue);
            } else {
                nextStroke = activeStroke.continueStroke(path, 0L, duration, willContinue);
            }
        } catch (IllegalArgumentException e) {
            gestureBusy = false;
            activeStroke = null;
            return;
        }

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(nextStroke)
                .build();

        gestureBusy = true;
        fingerX = endX;
        fingerY = endY;
        if (!releasing) {
            accumulatedDx -= dx;
            accumulatedDy -= dy;
        }

        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription description) {
                gestureBusy = false;
                activeStroke = nextStroke;

                if (pendingRelease || !enabled || !targetForeground) {
                    // The completed stroke deliberately kept the pointer down.
                    // Send one final continuation with willContinue=false to release it cleanly.
                    pendingRelease = false;
                    dispatchReleaseStroke();
                    return;
                }

                // Immediately submit the next continuation. The pointer stays down.
                dispatchNextContinuousStroke();
            }

            @Override public void onCancelled(GestureDescription description) {
                gestureBusy = false;
                activeStroke = null;
                accumulatedDx *= 0.9f;
                accumulatedDy *= 0.9f;
            }
        }, null);

        if (!accepted) {
            gestureBusy = false;
            activeStroke = null;
            if (!releasing) {
                accumulatedDx += dx;
                accumulatedDy += dy;
            }
        }
    }

    private void dispatchReleaseStroke() {
        if (activeStroke == null) {
            gestureBusy = false;
            return;
        }

        Path path = new Path();
        path.moveTo(fingerX, fingerY);
        path.lineTo(fingerX, fingerY);

        final GestureDescription.StrokeDescription releaseStroke;
        try {
            releaseStroke = activeStroke.continueStroke(path, 0L, 30L, false);
        } catch (IllegalArgumentException e) {
            gestureBusy = false;
            activeStroke = null;
            return;
        }

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(releaseStroke)
                .build();

        gestureBusy = true;
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription description) {
                gestureBusy = false;
                activeStroke = null;
            }

            @Override public void onCancelled(GestureDescription description) {
                gestureBusy = false;
                activeStroke = null;
            }
        }, null);

        if (!accepted) {
            gestureBusy = false;
            activeStroke = null;
        }
    }

    private void ensureFingerAnchor() {
        if (!Float.isNaN(fingerX) && !Float.isNaN(fingerY)) return;
        resetFingerAnchor();
    }

    private void resetFingerAnchor() {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        fingerX = dm.widthPixels * 0.78f;
        fingerY = dm.heightPixels * 0.52f;
        accumulatedDx = 0f;
        accumulatedDy = 0f;
    }

    private float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    public void onDestroy() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        if (windowManager != null && overlayButton != null) {
            try { windowManager.removeView(overlayButton); } catch (Exception ignored) {}
        }
        overlayButton = null;
        overlayShown = false;
        if (INSTANCE == this) INSTANCE = null;
        super.onDestroy();
    }
}
